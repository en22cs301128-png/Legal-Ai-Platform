import os
from dotenv import load_dotenv
load_dotenv()
from langchain_groq import ChatGroq

api_key = os.getenv("OPENAI_API_KEY")
llm = ChatGroq(model="llama-3.1-8b-instant", groq_api_key=api_key)

try:
    response = llm.invoke("Hello")
    print(response.content)
except Exception as e:
    print(f"Error: {e}")
