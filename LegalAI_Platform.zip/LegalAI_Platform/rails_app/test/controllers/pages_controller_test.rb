require "test_helper"

class PagesControllerTest < ActionDispatch::IntegrationTest
  test "should get chat" do
    get pages_chat_url
    assert_response :success
  end

  test "should get calendar" do
    get pages_calendar_url
    assert_response :success
  end

  test "should get reports" do
    get pages_reports_url
    assert_response :success
  end

  test "should get settings" do
    get pages_settings_url
    assert_response :success
  end

  test "should get users" do
    get pages_users_url
    assert_response :success
  end
end
