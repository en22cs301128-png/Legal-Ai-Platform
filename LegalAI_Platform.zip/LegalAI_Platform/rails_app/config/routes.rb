Rails.application.routes.draw do
  get "pages/chat"
  get "pages/calendar"
  get "pages/reports"
  get "pages/settings"
  get "pages/users"
  resources :legal_cases do
    resources :documents, only: [:create, :destroy]
    post 'chat', on: :member
  end
  devise_for :users
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Render dynamic PWA files from app/views/pwa/* (remember to link manifest in application.html.erb)
  # get "manifest" => "rails/pwa#manifest", as: :pwa_manifest
  # get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker

  get 'researcher', to: 'research#index', as: :researcher
  post 'researcher/ask', to: 'research#ask', as: :researcher_ask
  
  get 'chat', to: 'pages#chat', as: :chat
  get 'calendar', to: 'pages#calendar', as: :calendar
  get 'reports', to: 'pages#reports', as: :reports
  get 'settings', to: 'pages#settings', as: :settings
  get 'users', to: 'pages#users', as: :users
  post 'dashboard/chat', to: 'legal_cases#dashboard_chat', as: :dashboard_chat

  authenticated :user do
    root "legal_cases#index", as: :authenticated_root
  end

  unauthenticated do
    root "home#landing"
  end
end
