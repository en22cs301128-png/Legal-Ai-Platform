class CreateDocuments < ActiveRecord::Migration[8.1]
  def change
    create_table :documents do |t|
      t.string :filename
      t.string :content_type
      t.integer :file_size
      t.references :legal_case, null: false, foreign_key: true

      t.timestamps
    end
  end
end
