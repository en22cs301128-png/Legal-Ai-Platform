class AddCaseNumberToLegalCases < ActiveRecord::Migration[8.1]
  def change
    add_column :legal_cases, :case_number, :string
  end
end
