class CreateFindings < ActiveRecord::Migration[8.1]
  def change
    create_table :findings do |t|
      t.text :content
      t.string :task
      t.references :user, null: false, foreign_key: true

      t.timestamps
    end
  end
end
