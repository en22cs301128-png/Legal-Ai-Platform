class Document < ApplicationRecord
  belongs_to :legal_case
end
