class Finding < ApplicationRecord
  belongs_to :user
end
