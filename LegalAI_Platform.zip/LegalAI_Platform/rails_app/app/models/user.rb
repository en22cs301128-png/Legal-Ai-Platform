class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_many :legal_cases, dependent: :destroy
  has_many :findings, dependent: :destroy
  has_many :documents, through: :legal_cases
end
