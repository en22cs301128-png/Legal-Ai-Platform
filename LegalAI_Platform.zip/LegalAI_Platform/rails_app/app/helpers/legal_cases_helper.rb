module LegalCasesHelper
end
