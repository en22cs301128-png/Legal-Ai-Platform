json.extract! legal_case, :id, :title, :description, :status, :user_id, :created_at, :updated_at
json.url legal_case_url(legal_case, format: :json)
