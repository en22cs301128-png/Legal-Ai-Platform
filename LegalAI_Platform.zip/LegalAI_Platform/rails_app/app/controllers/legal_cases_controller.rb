class LegalCasesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_legal_case, only: %i[ show edit update destroy chat ]

  # GET /legal_cases or /legal_cases.json
  def index
    @legal_cases = current_user.legal_cases.all
    @recent_documents = current_user.documents.order(created_at: :desc).limit(5)
    @recent_findings = current_user.findings.order(created_at: :desc).limit(5)
  end

  def dashboard_chat
    query = params[:query]
    if query.present?
      begin
        conn = Faraday.new(url: ENV.fetch('AI_SERVICE_URL', 'http://ai_service:8000'))
        response = conn.post('/chat') do |req|
          req.headers['Content-Type'] = 'application/json'
          req.body = { query: query }.to_json
        end
        
        if response.success?
          result = JSON.parse(response.body)
          @chat_response = result['answer']
        else
          @chat_error = "AI Service Error: #{response.body}"
        end
      rescue => e
        @chat_error = "Connection Error: #{e.message}"
      end
    end
    index # Load dashboard data
    render :index
  end

  # GET /legal_cases/1 or /legal_cases/1.json
  def show
  end

  # GET /legal_cases/new
  def new
    @legal_case = current_user.legal_cases.build
  end

  # GET /legal_cases/1/edit
  def edit
  end

  # POST /legal_cases or /legal_cases.json
  def create
    @legal_case = current_user.legal_cases.build(legal_case_params)

    respond_to do |format|
      if @legal_case.save
        format.html { redirect_to @legal_case, notice: "Legal case was successfully created." }
        format.json { render :show, status: :created, location: @legal_case }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @legal_case.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /legal_cases/1 or /legal_cases/1.json
  def update
    respond_to do |format|
      if @legal_case.update(legal_case_params)
        format.html { redirect_to @legal_case, notice: "Legal case was successfully updated.", status: :see_other }
        format.json { render :show, status: :ok, location: @legal_case }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @legal_case.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /legal_cases/1 or /legal_cases/1.json
  def destroy
    @legal_case.destroy!

    respond_to do |format|
      format.html { redirect_to legal_cases_path, notice: "Legal case was successfully destroyed.", status: :see_other }
      format.json { head :no_content }
    end
  end

  def chat
    query = params[:query]
    if query.present?
      begin
        conn = Faraday.new(url: ENV.fetch('AI_SERVICE_URL', 'http://ai_service:8000'))
        response = conn.post('/chat') do |req|
          req.headers['Content-Type'] = 'application/json'
          req.body = { query: query }.to_json
        end
        
        if response.success?
          result = JSON.parse(response.body)
          @chat_response = result['answer']
        else
          @chat_error = "AI Service Error: #{response.body}"
        end
      rescue => e
        @chat_error = "Connection Error: #{e.message}"
      end
    end
    
    render :show
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_legal_case
      @legal_case = current_user.legal_cases.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def legal_case_params
      params.expect(legal_case: [ :title, :description, :status, :user_id ])
    end
end
