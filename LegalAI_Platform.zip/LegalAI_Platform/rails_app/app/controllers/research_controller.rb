class ResearchController < ApplicationController
  before_action :authenticate_user!

  def index
    @findings = current_user.findings.order(created_at: :desc)
  end

  def ask
    query = params[:query]
    if query.present?
      begin
        conn = Faraday.new(url: ENV.fetch('AI_SERVICE_URL', 'http://127.0.0.1:9000')) do |f|
          f.options[:timeout] = 300
          f.options[:open_timeout] = 10
        end
        response = conn.post('/agent') do |req|
          req.headers['Content-Type'] = 'application/json'
          req.body = { task: query }.to_json
        end
        
        if response.success?
          result = JSON.parse(response.body)
          @research_result = result['result']
          # Store findings
          current_user.findings.create!(task: query, content: @research_result)
          redirect_to researcher_path, notice: "Research mission completed."
          return
        else
          flash.now[:alert] = "AI Agent Error: #{response.body}"
        end
      rescue => e
        flash.now[:alert] = "Connection Error: #{e.message}"
      end
    end
    @findings = current_user.findings.order(created_at: :desc)
    render :index
  end

  def chat
    query = params[:query]
    if query.present?
      begin
        conn = Faraday.new(url: ENV.fetch('AI_SERVICE_URL', 'http://ai_service:8000'))
        response = conn.post('/chat') do |req|
          req.headers['Content-Type'] = 'application/json'
          req.body = { query: query }.to_json
        end
        
        if response.success?
          result = JSON.parse(response.body)
          @chat_response = result['answer']
        else
          @chat_error = "AI Service Error: #{response.body}"
        end
      rescue => e
        @chat_error = "Connection Error: #{e.message}"
      end
    end
    @findings = current_user.findings.order(created_at: :desc)
    render :index
  end
end
