class PagesController < ApplicationController
  def chat
  end

  def calendar
  end

  def reports
  end

  def settings
  end

  def users
  end
end
