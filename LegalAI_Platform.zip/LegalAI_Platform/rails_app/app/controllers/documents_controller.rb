class DocumentsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_legal_case

  def create
    @document = @legal_case.documents.build(document_params)
    
    if @document.save
      # Read the file and send to FastAPI AI Service
      uploaded_file = params[:document][:file]
      if uploaded_file.present?
        # Note: In a production app, we would process this asynchronously via Sidekiq
        begin
          conn = Faraday.new(url: ENV.fetch('AI_SERVICE_URL', 'http://ai_service:8000')) do |f|
            f.request :multipart
            f.request :url_encoded
            f.adapter Faraday.default_adapter
          end

          payload = {
            file: Faraday::Multipart::FilePart.new(
              uploaded_file.tempfile.path,
              uploaded_file.content_type,
              uploaded_file.original_filename
            )
          }

          response = conn.post('/upload', payload)
          
          if response.success?
            flash[:notice] = "Document uploaded and embedded successfully."
          else
            flash[:alert] = "Failed to process document in AI service: #{response.body}"
          end
        rescue => e
          flash[:alert] = "Error connecting to AI service: #{e.message}"
        end
      end
      
      redirect_to @legal_case
    else
      redirect_to @legal_case, alert: "Failed to upload document."
    end
  end

  def destroy
    @document = @legal_case.documents.find(params[:id])
    @document.destroy
    redirect_to @legal_case, notice: "Document removed."
  end

  private

  def set_legal_case
    @legal_case = current_user.legal_cases.find(params[:legal_case_id])
  end

  def document_params
    params.require(:document).permit(:filename, :content_type, :file_size)
  end
end
